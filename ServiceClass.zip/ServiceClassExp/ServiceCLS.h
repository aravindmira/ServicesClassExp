//
//  ServiceCLS.h
//  
//
//  Created by 8KMILES on 13/06/19.
//

#import <Foundation/Foundation.h>
#import "HomeVC.h"

#define ConfigurationJsonURL @"Apple"
#define ConfigurationWebURL @"Orange"


NS_ASSUME_NONNULL_BEGIN

@interface ServiceCLS : NSObject
@property (strong, nonatomic) id delegate;
@property(strong,nonatomic)NSString *LangSel;
-(void)GetDataFromWebService:(NSString*)serviceName;
-(void)PostDataFromWebService:(NSString*)serviceName :(NSMutableDictionary*)ParamDic;


@end

NS_ASSUME_NONNULL_END
