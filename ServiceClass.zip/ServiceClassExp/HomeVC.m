//
//  HomeVC.m
//  ServiceClassExp
//
//  Created by Aravind on 11/22/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

#import "HomeVC.h"
#import "ServiceCLS.h"
@interface HomeVC ()

@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSMutableDictionary *Dic;
    ServiceCLS *serv=[[ServiceCLS alloc]init];
       serv.delegate=self;
       [serv PostDataFromWebService:@"MoviesDetail" :Dic];
}
-(void)ReloadData{
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
