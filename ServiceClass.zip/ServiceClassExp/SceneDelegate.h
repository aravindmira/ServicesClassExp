//
//  SceneDelegate.h
//  ServiceClassExp
//
//  Created by Aravind on 11/22/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

