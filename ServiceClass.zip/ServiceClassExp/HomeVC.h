//
//  HomeVC.h
//  ServiceClassExp
//
//  Created by Aravind on 11/22/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeVC : UIViewController
@property(nonatomic,strong)NSMutableDictionary*datasource;
-(void)ReloadData;
@end

NS_ASSUME_NONNULL_END
