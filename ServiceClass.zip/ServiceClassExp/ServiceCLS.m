//
//  ServiceCLS.m
//  
//
//  Created by 8KMILES on 13/06/19.
//

#import "ServiceCLS.h"

@implementation ServiceCLS
{
    NSArray*responseArr;
}
-(void)GetDataFromWebService:(NSString*)serviceName{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    NSString *url;
    if ([serviceName isEqualToString:@"HomeVC"]) {
        url=[NSString stringWithFormat:@"%@getFilms?lang=%@",ConfigurationJsonURL,self.LangSel];
    
    }else  if ([serviceName isEqualToString:@"CinemasVC"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"getCinemas"];
    }
    else  if ([serviceName isEqualToString:@"GetUpComing"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"getUpcommingMovies"];
    }
    else if ([serviceName isEqualToString:@"HomeVCGetLang"]){
         url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"getLanguages"];
    }
   
    
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    NSLog(@"url is %@",url);
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (data!=nil) {
            self->responseArr  = [NSJSONSerialization JSONObjectWithData:data
                                                                         options:kNilOptions
                                                                           error:&error];
            if ([serviceName isEqualToString:@"HomeVC"]) {
                dispatch_async(dispatch_get_main_queue(),^{
                    HomeVC *tempObj=self.delegate;
                    tempObj.datasource=self->responseArr;
                    [tempObj ReloadData];
                });
            }
//            else if ([serviceName isEqualToString:@"GetUpComing"]) {
//                dispatch_async(dispatch_get_main_queue(),^{
//                    HomeVC *tempObj=self.delegate;
//                    tempObj.datasource=self->responseArr;
//                    [tempObj reloadData];
//                });
//            }
//            else  if ([serviceName isEqualToString:@"CinemasVC"]) {
//                dispatch_async(dispatch_get_main_queue(),^{
//                    CinemasVC*tempObj=self.delegate;
//                    tempObj.datasource=self->responseArr;
//                    [tempObj reloadData];
//                });
//            }
//            else if ([serviceName isEqualToString:@"HomeVCGetLang"]){
//                 dispatch_async(dispatch_get_main_queue(),^{
//                     HomeVC *tempObj=self.delegate;
//                     tempObj.responselangArr=self->responseArr;
//                     [tempObj reloadLang];
//                 });
//            }
            
            
        }else{
            NSLog(@"check the network");
           
           

        }
        
        
        
    }]resume];
}
-(void)PostDataFromWebService:(NSString*)serviceName :(NSMutableDictionary*)ParamDic{
    
    NSString *params;
    NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
    
   
    NSString *url;
    if ([serviceName isEqualToString:@"ContactUs"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationWebURL,@"contactUs/create"];
         params = [NSString stringWithFormat:@"name=%@&mobileNo=%@&email=%@&typeOfSupport=%@&message=%@",[ParamDic  objectForKey:@"name"],[ParamDic  objectForKey:@"mobileNo"],[ParamDic  objectForKey:@"email"],[ParamDic  objectForKey:@"typeOfSupport"],[ParamDic  objectForKey:@"message"]];
    }else  if ([serviceName isEqualToString:@"CinemasVC"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"getCinemas"];
    }
    else  if ([serviceName isEqualToString:@"CinemasDetail"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"cinemasTicketBooking"];
       params = [NSString stringWithFormat:@"cinemas_id=%@",[ParamDic  objectForKey:@"cinemas_id"]];
        
    }
    else  if ([serviceName isEqualToString:@"MoviesDetail"]) {
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"moviesTicketBooking"];
        params = [NSString stringWithFormat:@"movies_id=%@",[ParamDic  objectForKey:@"movies_id"]];
        
    }
    else if ([serviceName isEqualToString:@"HomeVC"]){
        url=[NSString stringWithFormat:@"%@%@",ConfigurationJsonURL,@"getFilms"];
        params = [NSString stringWithFormat:@"lang=%@&search=%@",[ParamDic  objectForKey:@"lang"],[ParamDic  objectForKey:@"search"]];
        
    }
    NSLog(@"Service name is %@",url);
    NSLog(@"param %@ ",params);
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //Create POST Params and add it to HTTPBody
   
    [urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];

    [urlRequest setHTTPMethod:@"POST"];
  //  [urlRequest setHTTPBody:params];
    
    //Create task
    NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        //Handle your response here
        NSDictionary *responseDict;
        @try {
             responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        } @catch (NSException *exception) {
            NSLog(@"Errir is %@",exception);
        }
   
        
        NSLog(@"%@",responseDict);
        if ([serviceName isEqualToString:@"ContactUs"]) {
//            ContactUsVC *tempObj=self.delegate;
//
//            tempObj.Message=[responseDict objectForKey:@"status"];
//
//            [tempObj reloadData];
           
        }else  if ([serviceName isEqualToString:@"CinemasVC"]) {
           
        }
        else  if ([serviceName isEqualToString:@"CinemasDetail"]) {
//           CinemasDetailVC *tempObj=self.delegate;
//            tempObj.datasourceDic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//
//            [tempObj ReloadData];
            
        }
        else  if ([serviceName isEqualToString:@"MoviesDetail"]) {
//            HomeDVC *tempObj=self.delegate;
//            tempObj.datasourceDic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//
//            [tempObj ReloadData];
            
        }
        else if ([serviceName isEqualToString:@"HomeVC"]) {
            dispatch_async(dispatch_get_main_queue(),^{
                if (data!=nil) {
                    self->responseArr  = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                }
//                HomeVC *tempObj=self.delegate;
//                tempObj.datasource=self->responseArr;
//                [tempObj reloadData];
            });
        }

        
    }];
    [dataTask resume];
}

@end
